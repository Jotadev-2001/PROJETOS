import React, { useState } from 'react';
import { View, Text, TextInput, Button, FlatList, TouchableOpacity, StyleSheet } from 'react-native';

// Importa os dados dos direitos do cidadão (simulando banco de dados)
import { direitos } from './dadosDireitos';

export default function App() {
  // Estados para controlar login, tela atual, formulário e seleção
  const [usuarioLogado, setUsuarioLogado] = useState(null);
  const [tela, setTela] = useState('login');
  const [email, setEmail] = useState('');
  const [senha, setSenha] = useState('');
  const [erro, setErro] = useState('');
  const [selecionado, setSelecionado] = useState(null);

  // Estado para guardar o filtro da categoria atual (null = sem filtro)
  const [filtroCategoria, setFiltroCategoria] = useState(null);

  // Extrai as categorias únicas para mostrar como botões de filtro
  const categorias = [...new Set(direitos.map(d => d.categoria))];

  // Filtra os direitos para mostrar somente os da categoria selecionada
  const direitosFiltrados = filtroCategoria
    ? direitos.filter(d => d.categoria === filtroCategoria)
    : direitos;

  // Função para simular login simples (aceita qualquer email e senha não vazios)
  function login() {
    if (email.trim() === '' || senha.trim() === '') {
      setErro('Por favor, preencha email e senha');
      return;
    }
    setUsuarioLogado(email);
    setTela('lista');
    setErro('');
  }

  // Se não estiver logado, mostra tela de login
  if (!usuarioLogado) {
    return (
      <View style={styles.container}>
        <Text style={styles.header}>Login</Text>
        <TextInput
          placeholder="Email"
          value={email}
          onChangeText={setEmail}
          style={styles.input}
          keyboardType="email-address"
          autoCapitalize="none"
        />
        <TextInput
          placeholder="Senha"
          value={senha}
          onChangeText={setSenha}
          style={styles.input}
          secureTextEntry
        />
        {erro ? <Text style={styles.erro}>{erro}</Text> : null}
        <Button title="Entrar" onPress={login} />
      </View>
    );
  }

  // Se um direito estiver selecionado, mostra a tela de detalhe
  if (selecionado) {
    return (
      <View style={styles.container}>
        <Text style={styles.header}>{selecionado.titulo}</Text>
        <Text style={styles.categoria}>{selecionado.categoria}</Text>
        <Text style={styles.conteudo}>{selecionado.conteudo}</Text>

        <Button title="Voltar" onPress={() => setSelecionado(null)} />
        <Button
          title="Sair"
          color="red"
          onPress={() => {
            setUsuarioLogado(null);
            setEmail('');
            setSenha('');
            setSelecionado(null);
            setFiltroCategoria(null);
          }}
        />
      </View>
    );
  }

  // Tela principal: lista com filtro por categoria
  return (
    <View style={styles.container}>
      <Text style={styles.header}>Guia de Direitos do Cidadão</Text>

      {/* Botões de filtro */}
      <View style={{ flexDirection: 'row', marginBottom: 15 }}>
        {/* Botão "Todos" para limpar o filtro */}
        <TouchableOpacity
          onPress={() => setFiltroCategoria(null)}
          style={[styles.botaoFiltro, filtroCategoria === null && styles.botaoFiltroAtivo]}
        >
          <Text style={styles.textoFiltro}>Todos</Text>
        </TouchableOpacity>

        {/* Botões para cada categoria */}
        {categorias.map(categoria => (
          <TouchableOpacity
            key={categoria}
            onPress={() => setFiltroCategoria(categoria)}
            style={[styles.botaoFiltro, filtroCategoria === categoria && styles.botaoFiltroAtivo]}
          >
            <Text style={styles.textoFiltro}>{categoria}</Text>
          </TouchableOpacity>
        ))}
      </View>

      {/* Lista dos direitos filtrados */}
      <FlatList
        data={direitosFiltrados}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => (
          <TouchableOpacity onPress={() => setSelecionado(item)} style={styles.card}>
            <Text style={styles.tituloCard}>{item.titulo}</Text>
            <Text style={styles.categoria}>{item.categoria}</Text>
          </TouchableOpacity>
        )}
      />

      {/* Botão para sair do app */}
      <Button
        title="Sair"
        color="red"
        onPress={() => {
          setUsuarioLogado(null);
          setEmail('');
          setSenha('');
          setFiltroCategoria(null);
        }}
      />
    </View>
  );
}

// Estilos usados no app
const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    padding: 20,
    paddingTop: 50,
  },
  header: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 20,
  },
  input: {
    borderWidth: 1,
    borderColor: '#888',
    padding: 10,
    marginBottom: 15,
    borderRadius: 6,
  },
  erro: {
    color: 'red',
    marginBottom: 10,
  },
  card: {
    backgroundColor: '#f3f3f3',
    padding: 15,
    borderRadius: 8,
    marginBottom: 12,
  },
  tituloCard: {
    fontSize: 18,
    fontWeight: 'bold',
  },
  categoria: {
    color: '#555',
    marginTop: 4,
  },
  conteudo: {
    fontSize: 16,
    marginBottom: 20,
  },
  botaoFiltro: {
    paddingHorizontal: 12,
    paddingVertical: 6,
    backgroundColor: '#ddd',
    borderRadius: 20,
    marginRight: 10,
  },
  botaoFiltroAtivo: {
    backgroundColor: '#3b82f6',
  },
  textoFiltro: {
    color: '#000',
  },
});
